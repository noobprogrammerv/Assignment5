package Validator;

public class ValidateException extends RuntimeException {
    public ValidateException(String message) { super(message); }
}

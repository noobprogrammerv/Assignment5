package Repository;
import java.util.ArrayList;
import java.util.Iterator;
import Filter.FilterCarsByYear;
import Package.Car;

public class CarRepository extends MemoryRepository<String, Car> {

}

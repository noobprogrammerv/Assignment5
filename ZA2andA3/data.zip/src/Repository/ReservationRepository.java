package Repository;
import java.util.ArrayList;
import java.util.Iterator;
import Filter.FilterCarsByYear;
import Package.Reservation;

public class ReservationRepository extends MemoryRepository<String, Reservation> {

}

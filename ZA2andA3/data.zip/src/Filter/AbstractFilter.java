package Filter;

public interface AbstractFilter<T> {
    boolean acceptEntity(T t);
}

package Service;

import Package.Reservation;
import Repository.IRepository;

import java.time.LocalDate;
import java.util.ArrayList;


public class ReservationsService {
    private final IRepository<String, Reservation> reservationsRepo;

    public ReservationsService(IRepository<String, Reservation> repo) {
        this.reservationsRepo = repo;
    }

    public void addReservation(String id, LocalDate date, String carId) {
        Reservation reservation = new Reservation(id, date, carId);
        reservationsRepo.addEntity(reservation.getId(), reservation);
    }

    public void deleteReservation(String id) {
        reservationsRepo.deleteEntity(id);
    }
    public Reservation findReservationById(String id) {
        return reservationsRepo.findEntityById(id);
    }
    public void modifyReservation(String id, LocalDate date, String carId) {
        Reservation reservation = new Reservation(id, date, carId);
        reservationsRepo.modifyEntity(reservation.getId(), reservation);
    }

    public ArrayList<Reservation> getAll() {
        ArrayList<Reservation> reservations = new ArrayList<>();

        for (Reservation reservation : reservationsRepo.getAllEntities()) {
            reservations.add(reservation);
        }

        return reservations;
    }
}

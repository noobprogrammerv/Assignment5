package Service;

import Package.Car;
import Repository.IRepository;

import java.util.ArrayList;

public class CarsService {
    private final IRepository<String, Car> carsRepo;

    public CarsService(IRepository<String, Car> repo) {
        this.carsRepo = repo;
    }

    public void addCar(String id, String make, String model, int year) {
        if (year < 0) {
            throw new RuntimeException("Year cannot be negative!");
        }
        Car car = new Car(id, make, model, year);
        carsRepo.addEntity(car.getId(), car);
    }

    public void deleteCar(String id) {
        carsRepo.deleteEntity(id);
    }
    public Car findCarById(String id) {
        return carsRepo.findEntityById(id);
    }
    public void modifyCar(String id, String make, String model, int year) {
        Car car = new Car(id, make, model, year);
        carsRepo.modifyEntity(car.getId(), car);
    }

    public ArrayList<Car> getAll() {
        ArrayList<Car> cars = new ArrayList<>();

        for (Car car : carsRepo.getAllEntities()) {
            cars.add(car);
        }

        return cars;
    }
}

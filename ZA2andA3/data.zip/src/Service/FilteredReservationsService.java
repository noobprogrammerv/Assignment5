package Service;

import Filter.AbstractFilter;
import Package.Reservation;
import Repository.IRepository;

import java.util.ArrayList;

public class FilteredReservationsService extends ReservationsService {
    private AbstractFilter<Reservation> filter;
    public FilteredReservationsService(IRepository <String, Reservation> repo, AbstractFilter<Reservation> filter) {
        super(repo);
        this.filter = filter;
    }
    @Override
    public ArrayList<Reservation> getAll() {
        ArrayList<Reservation> reservations = super.getAll();
        ArrayList<Reservation> filteredReservations = new ArrayList<>();
        for (Reservation reservation : reservations) {
            if (filter.acceptEntity(reservation)) {
                filteredReservations.add(reservation);
            }
        }
        return filteredReservations;
    }
}

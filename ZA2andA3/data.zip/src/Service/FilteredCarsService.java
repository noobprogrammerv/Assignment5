package Service;

import Filter.AbstractFilter;
import Package.Car;
import Repository.IRepository;

import java.util.ArrayList;


public class FilteredCarsService extends CarsService {
    private AbstractFilter<Car> filter;
    public FilteredCarsService(IRepository <String, Car> repo, AbstractFilter<Car> filter) {
        super(repo);
        this.filter = filter;
    }
    @Override
    public ArrayList<Car> getAll() {
        ArrayList<Car> cars = super.getAll();
        ArrayList<Car> filteredDCars = new ArrayList<>();
        for (Car car : cars) {
            if (filter.acceptEntity(car)) {
                filteredDCars.add(car);
            }
        }
        return filteredDCars;
    }

}

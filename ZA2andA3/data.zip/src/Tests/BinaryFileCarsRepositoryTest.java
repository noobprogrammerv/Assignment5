package Tests;

import Package.Car;
import Repository.BinaryFileCarsRepository;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.util.Iterator;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class BinaryFileCarsRepositoryTest {

    private String fileName = "testCarsRepo.bin";

    // Helper method to get the size of an Iterable
    private int getSize(Iterable<Car> iterable) {
        int nrOfCars = 0;
        Iterator<Car> iterator = iterable.iterator();
        while (iterator.hasNext()) {
            iterator.next();
            nrOfCars++;
        }
        return nrOfCars;
    }

    @Test
    public void writeToFileAndReadFromFile() {
        BinaryFileCarsRepository repo = new BinaryFileCarsRepository(fileName);
        Car car1 = new Car("1", "Dacia", "Logan", 2008);
        Car car2 = new Car("2", "Renault", "Clio", 2012);

        // Add cars to the repository and write to file
        repo.addEntity(car1.getId(), car1);
        repo.addEntity(car2.getId(), car2);
        repo.writeToFile();

        // Verify that the repository contains the saved cars
        assertEquals(2, getSize(repo.getAllEntities()));
        assertEquals(car1, repo.findEntityById("1"));
        assertEquals(car2, repo.findEntityById("2"));
    }

    @Test
    public void readFromFileWhenFileDoesNotExist() {
        // Delete file if it exists to simulate "file does not exist" scenario
        File file = new File(fileName);
        file.delete();

        BinaryFileCarsRepository repo = new BinaryFileCarsRepository(fileName);
        repo.readFromFile();

        /*// Verify that the repository is empty
        assertEquals(0, getSize(repo.getAllEntities()));*/

    }
}
